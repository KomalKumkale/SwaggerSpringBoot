package com.java.service.impl;

import com.java.model.User;
import com.java.service.UserService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Override
    public User getUserById(String userid) {
        User user = new User();
        user.setFirstname("Komal");
        user.setLastname("Kumkale");
        user.setLocation("Pune");
        user.setPincode("415523");
        user.setCountrycode("IN");
        return user;
    }

    @Override
    public List<User> getAllUsers() {
        User user = new User();
        user.setFirstname("Komal");
        user.setLastname("Kumkale");
        user.setLocation("Pune");
        user.setPincode("415523");
        user.setCountrycode("IN");
        return Collections.singletonList(user);
    }

    @Override
    public String deleteUserById(String userid) {
        return "Deleted Successfully";
    }

    @Override
    public User saveUser(User user) {
        return user;
    }
}
